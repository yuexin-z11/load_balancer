var searchData=
[
  ['addblock_0',['addBlock',['../classipBlocker.html#a0315b7d895f864ce391f5f4b17d42139',1,'ipBlocker']]],
  ['assign_1',['assign',['../classWebServer.html#a82dc9a731306abab80ab5be89f302920',1,'WebServer']]]
];
