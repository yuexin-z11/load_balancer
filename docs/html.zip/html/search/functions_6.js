var searchData=
[
  ['isblocked_64',['isBlocked',['../classipBlocker.html#ac7f1045b30287527887263b030df9a6e',1,'ipBlocker']]],
  ['isidle_65',['isIdle',['../classWebServer.html#a3dc0403ae54b9072865b36a57d7fd6a7',1,'WebServer']]]
];
