var searchData=
[
  ['ipin_74',['ipIn',['../structRequest.html#a673250f9e8c5b76f201ce4473d6bd38a',1,'Request']]],
  ['ipout_75',['ipOut',['../structRequest.html#a5b6261d9519372caf3931cd6b33a56b1',1,'Request']]]
];
