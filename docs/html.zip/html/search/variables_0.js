var searchData=
[
  ['ipin_68',['ipIn',['../structRequest.html#a673250f9e8c5b76f201ce4473d6bd38a',1,'Request']]],
  ['ipout_69',['ipOut',['../structRequest.html#a5b6261d9519372caf3931cd6b33a56b1',1,'Request']]]
];
