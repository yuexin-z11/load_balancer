var searchData=
[
  ['type_34',['type',['../structRequest.html#a3bd4fe5482cd4ed6b21bfe7c28462041',1,'Request']]]
];
