var searchData=
[
  ['gettotalprocessed_7',['getTotalProcessed',['../classLoadBalancer.html#a650baa17f89cf43513df60d04f851dad',1,'LoadBalancer']]],
  ['gettotalscaledowns_8',['getTotalScaleDowns',['../classLoadBalancer.html#a2771227f2bf5c5aba849059012673b99',1,'LoadBalancer']]],
  ['gettotalscaleups_9',['getTotalScaleUps',['../classLoadBalancer.html#afaf13702973177d826c6cfbe4041fd6d',1,'LoadBalancer']]]
];
